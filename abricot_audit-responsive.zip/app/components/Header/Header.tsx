import Image from "next/image"
import Link from "next/link"
import Logo from '@/public/image/logo.svg'
import UserIcon from "@/app/components/UserIcon/UserIcon"
import MenuItems from "@/app/components/MenuItems/MenuItems"
 

export default function Header(){
    return (
        // Responsive: 64px tall on a phone, the mockup's 94px from md (768px).
        // The gaps grow with the screen (gap-26 = the mockup's spacing, from lg)
        <header className="flex h-16 w-full items-center justify-between gap-3 bg-white px-4 md:h-[94px] md:gap-6 md:px-10 lg:gap-26">
            {/* The logo leads to the dashboard: its alt is the link's name for a screen reader.
                w-24 on a phone (96px), the mockup's 147px from md */}
            <Link href="/dashboard" className="shrink-0">
                <Image 
                    src={Logo}
                    alt="Abricot, tableau de bord"
                    loading="eager"
                    width={147}
                    // h-auto: the height follows the new width (keeps the logo's proportions)
                    className="h-auto w-24 md:w-[147px]"
                />
            </Link>
            {/* aria-label: names the navigation for screen readers ("Navigation principale") */}
            <nav aria-label="Navigation principale" className="flex items-center gap-2 md:gap-4">
                <MenuItems 
                    label="Tableau de bord"
                    icon="dashboard"
                    href="/dashboard"
                />
                <MenuItems
                    label="Projets"
                    icon="folder"
                    href="/projects"
                />
            </nav>
            <UserIcon/>

        </header>
    )
}