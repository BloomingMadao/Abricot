"use client"

import { useState } from "react"
import Chips from "@/app/components/Chips/Chips"
import Input from "@/app/components/Input/Input"
import TaskCard from "@/app/components/TaskCard/TaskCard"
import KanbanColumn from "@/app/components/KanbanColumn/KanbanColumn"
import MonthToolbar from "@/app/components/MonthToolbar/MonthToolbar"
import DashboardProjectCard from "@/app/components/DashboardProjectCard/DashboardProjectCard"
import SearchIcon from "@/public/image/searchIcon.svg"
import { dayKey, monthKey, monthOf, projectsByUrgency, type Month } from "@/app/lib/utils"
import type { AssignedTask, TaskStatus } from "@/app/lib/types"

// The Kanban columns (one per status), in the mockup's order
const KANBAN_COLUMNS: { status: TaskStatus; title: string }[] = [
    { status: "TODO", title: "À faire" },
    { status: "IN_PROGRESS", title: "En cours" },
    { status: "DONE", title: "Terminées" },
]

type DashboardTasksProps = {
    // The tasks assigned to the logged-in user, sorted by priority (by the page)
    tasks: AssignedTask[]
    // Today, "YYYY-MM-DD" (Paris time), computed on the server by the page:
    // the Kanban opens on the current month
    today: string
}

// The 3 views of the specifications:
// - "Liste": the tasks assigned to the user, the most urgent first (+ search);
// - "Kanban": the tasks of the MONTH, by status (with the month navigation);
// - "Projets": the projects in which the user has tasks, the most urgent first.
// CLIENT component: it handles what changes on the page (selected view, search, month).
// The tasks themselves are fetched by the page (server component) and come in as props.
export default function DashboardTasks({ tasks, today }: DashboardTasksProps) {
    const [view, setView] = useState<"list" | "kanban" | "projects">("list")
    const [search, setSearch] = useState("")
    // The month of the Kanban: the current month at first
    const [month, setMonth] = useState<Month>(() => monthOf(today))

    // Filtering on every keystroke: we keep the tasks whose title or description
    // contains the search text (case-insensitive)
    const query = search.trim().toLowerCase()
    const filteredTasks = tasks.filter(
        (task) =>
            task.title.toLowerCase().includes(query) ||
            (task.description ?? "").toLowerCase().includes(query)
    )

    // Kanban: only the tasks whose due date is in the month shown ("tâches du mois").
    // dayKey: the day in Paris time ("YYYY-MM-DD"), its first 7 characters are the month ("YYYY-MM")
    const shownKey = monthKey(month)
    const monthTasks = tasks.filter((task) => task.dueDate && dayKey(task.dueDate).startsWith(shownKey))
    // The months that have tasks: "Voir <month>" when the month shown is empty
    const monthsWithTasks = [
        ...new Set(tasks.flatMap((task) => (task.dueDate ? [dayKey(task.dueDate).slice(0, 7)] : []))),
    ]
    // Tasks without a due date belong to no month: they are only in the "Liste" view
    const withoutDueDateCount = tasks.filter((task) => !task.dueDate).length

    return (
        <>
            {/* View selection. flex-wrap: the 3 chips fit on a 375px phone */}
            <div className="mt-10 flex flex-wrap gap-2.5 md:mt-14">
                <Chips
                    label="Liste"
                    type="tasks"
                    isActive={view === "list"}
                    onClick={() => setView("list")}
                />
                <Chips
                    label="Kanban"
                    type="kanban"
                    isActive={view === "kanban"}
                    onClick={() => setView("kanban")}
                />
                <Chips
                    label="Projets"
                    type="projects"
                    isActive={view === "projects"}
                    onClick={() => setView("projects")}
                />
            </div>

            {view === "list" && (
                // .panel (globals.css): the white frame shared by the sections, responsive padding
                <section className="panel mt-7.5">
                    {/* Card header: title on the left, search on the right (below it on a phone / tablet) */}
                    <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                        <div>
                            {/* h2: a section of the page (the h1 is "Tableau de bord").
                                Class h5: the same look as before */}
                            <h2 className="h5">Mes tâches assignées</h2>
                            <p className="mt-1 text-grey-600">Par ordre de priorité</p>
                        </div>
                        {/* value + onChange: React knows the text on every keystroke.
                            className: Tailwind classes take precedence over those
                            of .input-default (margins, height, width).
                            Full width on a phone, the mockup's width (357px) from sm (640px) */}
                        <Input
                            label="Rechercher une tâche"
                            hideLabel
                            id="search-task"
                            type="search"
                            placeholder="Rechercher une tâche"
                            value={search}
                            onChange={(event) => setSearch(event.target.value)}
                            icon={SearchIcon}
                            wrapperClassName="w-full sm:w-auto"
                            className="my-0 h-[63px] w-full rounded-[10px] pl-8 text-sm placeholder:text-grey-600 sm:w-[357px]"
                        />
                    </div>

                    {/* The task list (or a message if there are none) */}
                    {tasks.length === 0 ? (
                        <p className="mt-10 text-grey-600">Aucune tâche ne vous est assignée.</p>
                    ) : filteredTasks.length === 0 ? (
                        <p className="mt-10 text-grey-600">
                            Aucune tâche ne correspond à « {search} ».
                        </p>
                    ) : (
                        <ul className="mt-10 flex flex-col gap-[18px]">
                            {filteredTasks.map((task) => (
                                <li key={task.id}>
                                    <TaskCard task={task} />
                                </li>
                            ))}
                        </ul>
                    )}
                </section>
            )}

            {view === "kanban" && (
                <section aria-label="Kanban des tâches du mois" className="mt-7.5">
                    {/* The month shown, previous / next month (the same toolbar as the project calendar) */}
                    <MonthToolbar month={month} today={today} monthsWithTasks={monthsWithTasks} onChange={setMonth} />
                    {withoutDueDateCount > 0 && (
                        <p className="mt-4 text-sm text-grey-600">
                            {withoutDueDateCount} tâche{withoutDueDateCount > 1 ? "s" : ""} sans échéance
                            {withoutDueDateCount > 1 ? " sont" : " est"} visible{withoutDueDateCount > 1 ? "s" : ""} dans la vue Liste.
                        </p>
                    )}

                    {/* One column per status. One below the other on a phone / tablet,
                        3 columns of equal width from lg (1024px).
                        lg:-mx-7.5: in the mockup, the columns overflow by 30px on each side */}
                    <div className="mt-8 grid grid-cols-1 items-start gap-[23px] lg:-mx-7.5 lg:mt-12.5 lg:grid-cols-3">
                        {KANBAN_COLUMNS.map((column) => (
                            <KanbanColumn
                                key={column.status}
                                title={column.title}
                                // Each column only gets the month's tasks with its status
                                // (still in priority order, since tasks is already sorted)
                                tasks={monthTasks.filter((task) => task.status === column.status)}
                            />
                        ))}
                    </div>
                </section>
            )}

            {view === "projects" && (
                <section className="panel mt-7.5">
                    <h2 className="h5">Mes projets</h2>
                    <p className="mt-1 text-grey-600">Les projets où vous avez des tâches, les plus urgents d&apos;abord</p>
                    {tasks.length === 0 ? (
                        <p className="mt-10 text-grey-600">Aucune tâche ne vous est assignée.</p>
                    ) : (
                        <ul className="mt-10 flex flex-col gap-[18px]">
                            {projectsByUrgency(tasks).map(({ project, tasks: projectTasks }) => (
                                <li key={project.id}>
                                    <DashboardProjectCard project={project} tasks={projectTasks} />
                                </li>
                            ))}
                        </ul>
                    )}
                </section>
            )}
        </>
    )
}