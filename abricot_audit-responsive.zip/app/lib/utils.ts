/**
 * ============================================================================
 *  SMALL DISPLAY HELPERS
 * ============================================================================
 *  The backend returns "technical" values (TODO, HIGH, ADMIN, ISO dates).
 *  These helpers turn them into readable French text for the interface.
 * ============================================================================
 */

import type { AssignedTask, Priority, Role, TaskStatus } from "./types";
import type { TagVariant } from "@/app/components/Tag/Tag";

/** Example: TASK_STATUS_LABELS["IN_PROGRESS"] → "En cours" */
export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  TODO: "À faire",
  IN_PROGRESS: "En cours",
  DONE: "Terminée",
};

/** Color of a status label (TaskCard, "Modifier" modal).
 *  Example: TASK_STATUS_VARIANTS["TODO"] → "error" (red) */
export const TASK_STATUS_VARIANTS: Record<TaskStatus, TagVariant> = {
  TODO: "error",
  IN_PROGRESS: "warning",
  DONE: "success",
};

/** Example: PRIORITY_LABELS["HIGH"] → "Haute" */
export const PRIORITY_LABELS: Record<Priority, string> = {
  LOW: "Basse",
  MEDIUM: "Moyenne",
  HIGH: "Haute",
  URGENT: "Urgente",
};

/** Example: ROLE_LABELS["CONTRIBUTOR"] → "Contributeur" */
export const ROLE_LABELS: Record<Role, string> = {
  ADMIN: "Administrateur",
  CONTRIBUTOR: "Contributeur",
};

/** Example: formatDate("2024-01-15T00:00:00.000Z") → "15 janvier 2024" */
export function formatDate(isoDate: string | null): string {
  if (!isoDate) return "Aucune échéance";
  return new Date(isoDate).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Europe/Paris",
  });
}


/** Example: getInitials("Alice Martin") → "AM" (the first 2 words) */
export function getInitials(name: string | null | undefined): string {
    if (!name) return "";

    const initials = name
    .split(" ")
    .filter((word) => word !== "")
    .slice(0,2)
    .map((word) => word.charAt(0).toUpperCase())
    .join("")

    return initials
}


/** Priority importance: the smaller the number, the more important it is.
 *  (The API sorts in ALPHABETICAL order: HIGH, LOW, MEDIUM, URGENT — not by importance.) */
export const PRIORITY_RANK: Record<Priority, number> = {
  URGENT: 0,
  HIGH: 1,
  MEDIUM: 2,
  LOW: 3,
};

/** Compares two tasks by urgency (for sort()): the priority first,
 *  then the closest due date (a task without a due date comes after the others). */
export function compareUrgency(
  a: { priority: Priority; dueDate: string | null },
  b: { priority: Priority; dueDate: string | null }
): number {
  const byPriority = PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority];
  if (byPriority !== 0) return byPriority;
  if (a.dueDate === b.dueDate) return 0;
  if (!a.dueDate) return 1;
  if (!b.dueDate) return -1;
  return a.dueDate.localeCompare(b.dueDate); // ISO dates: the text order is the date order
}

/** A project of the dashboard's "Projets" view, with the logged-in user's tasks in it */
export type ProjectWithMyTasks = {
  project: AssignedTask["project"];
  // The user's tasks in this project: those still to do first (most urgent first), then the done ones
  tasks: AssignedTask[];
};

/** The dashboard's "Projets" view (specifications: "the projects in which the user has assigned
 *  tasks, the most urgent first"). Built from the assigned tasks the page already has:
 *  no extra request to the API.
 *  A project is as urgent as its most urgent task that isn't done yet;
 *  the projects whose tasks are all done come last. */
export function projectsByUrgency(tasks: AssignedTask[]): ProjectWithMyTasks[] {
  // Group the tasks by project (Map: keeps the order in which the projects appear)
  const groups = new Map<string, ProjectWithMyTasks>();
  for (const task of tasks) {
    const group = groups.get(task.projectId) ?? { project: task.project, tasks: [] };
    group.tasks.push(task);
    groups.set(task.projectId, group);
  }

  const isDone = (task: AssignedTask) => task.status === "DONE";
  const projects = [...groups.values()].map((group) => ({
    ...group,
    // Not done first, then the most urgent first
    tasks: [...group.tasks].sort((a, b) => Number(isDone(a)) - Number(isDone(b)) || compareUrgency(a, b)),
  }));

  // The 1st task of each project is now its most urgent task (or a done one if all are done)
  return projects.sort((a, b) => {
    const [first] = a.tasks;
    const [other] = b.tasks;
    return Number(isDone(first)) - Number(isDone(other)) || compareUrgency(first, other);
  });
}

/** Color of a priority tag (dashboard "Projets" view).
 *  Example: PRIORITY_VARIANTS["URGENT"] → "error" (red) */
export const PRIORITY_VARIANTS: Record<Priority, TagVariant> = {
  URGENT: "error",
  HIGH: "warning",
  MEDIUM: "info",
  LOW: "grey",
};

/** Example: formatShortDate("2025-03-09T00:00:00.000Z") → "9 mars" */
export function formatShortDate(isoDate: string | null): string {
  if (!isoDate) return "Sans échéance";
  return new Date(isoDate).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    timeZone: "Europe/Paris",
  });
}

/** Example: formatDateTime("2026-03-23T10:20:00.000Z") → "23 mars, 11:20" (Paris time) */
export function formatDateTime(isoDate: string): string {
  const date = new Date(isoDate);
  const day = date.toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    timeZone: "Europe/Paris",
  });
  const time = date.toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Paris",
  });
  return `${day}, ${time}`;
}

// ----------------------------------------------------------------------------
// Days and months (calendar of a project page, Kanban of the dashboard).
// A day is written "YYYY-MM-DD" and a month "YYYY-MM": easy to compare and to use as keys.
// ----------------------------------------------------------------------------

/** A month. month: 0 = January, as in JavaScript dates */
export type Month = { year: number; month: number };

// "en-CA": the format of this locale is exactly YYYY-MM-DD
const PARIS_DAY = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Paris",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

/** The day of a date in Paris time, like formatShortDate.
 *  Example: dayKey("2024-02-28T23:30:00.000Z") → "2024-02-29" (it's already the 29th in Paris) */
export function dayKey(date: Date | string): string {
  return PARIS_DAY.format(new Date(date));
}

/** Example: monthOf("2026-11-10") → { year: 2026, month: 10 } (a "YYYY-MM" key also works) */
export function monthOf(key: string): Month {
  const [year, month] = key.split("-").map(Number);
  return { year, month: month - 1 };
}

/** Example: monthKey({ year: 2026, month: 10 }) → "2026-11" */
export function monthKey({ year, month }: Month): string {
  return `${year}-${String(month + 1).padStart(2, "0")}`;
}

/** Example: addMonths({ year: 2026, month: 0 }, -1) → { year: 2025, month: 11 }.
 *  Date.UTC handles the years (month -1 = December of the year before) */
export function addMonths({ year, month }: Month, offset: number): Month {
  const date = new Date(Date.UTC(year, month + offset, 1));
  return { year: date.getUTCFullYear(), month: date.getUTCMonth() };
}

const MONTH_LABEL = new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric", timeZone: "UTC" });

/** Example: formatMonth({ year: 2026, month: 10 }) → "novembre 2026" */
export function formatMonth({ year, month }: Month): string {
  return MONTH_LABEL.format(Date.UTC(year, month, 1));
}

/** The month closest to "shownKey" among "monthKeys" (months that have tasks):
 *  the next one, otherwise the last one before. undefined if there are none. */
export function closestMonthKey(monthKeys: string[], shownKey: string): string | undefined {
  const sorted = [...monthKeys].sort();
  return sorted.find((key) => key > shownKey) ?? sorted.findLast((key) => key < shownKey);
}

// ----------------------------------------------------------------------------
// Abricot's rule on tasks (the API doesn't know it: any project member could do it).
// Creating and deleting a task: any project member (as in the specifications).
// Editing: only the project owner and the people assigned to the task.
// ----------------------------------------------------------------------------

/** Can the logged-in user edit a task? The project owner, or a person assigned to it.
 *  Returns null when allowed, otherwise the error message (shown in a red alert).
 *  Used by the "Modifier" modal (TaskMenu, TaskCalendar) AND by updateTaskAction (the real check).
 *  assigneeIds: the ids of the people assigned to the task */
export function editTaskError(assigneeIds: string[], userId: string, isProjectOwner: boolean): string | null {
  if (isProjectOwner || assigneeIds.includes(userId)) return null;
  return "Seuls le propriétaire du projet et les personnes assignées peuvent modifier cette tâche";
}